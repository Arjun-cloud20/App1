import { EventData, Page } from '@nativescript/core';
import { CoursesViewModel } from '../../shared/view-models/courses-view-model';

export function navigatingTo(args: EventData) {
    const page = <Page>args.object;
    page.bindingContext = new CoursesViewModel();
}

export function onLanguageFilter(args: EventData) {
    const viewModel = (<Page>args.object).bindingContext;
    // TODO: Show language selection dialog
}

export function onLevelFilter(args: EventData) {
    const viewModel = (<Page>args.object).bindingContext;
    // TODO: Show level selection dialog
}

export function onCategoryFilter(args: EventData) {
    const viewModel = (<Page>args.object).bindingContext;
    // TODO: Show category selection dialog
}