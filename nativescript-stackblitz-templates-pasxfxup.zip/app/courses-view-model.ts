import { Observable } from '@nativescript/core';
import { Course, Language } from '../models/course.model';

export class CoursesViewModel extends Observable {
  private _courses: Course[] = [];
  private _selectedLanguage: Language = 'english';
  private _selectedLevel: string = 'all';
  private _selectedCategory: string = 'all';

  constructor() {
    super();
    this.loadCourses();
  }

  get courses(): Course[] {
    return this._courses;
  }

  get filteredCourses(): Course[] {
    return this._courses.filter((course) => {
      const languageMatch =
        this._selectedLanguage === 'all' ||
        course.language === this._selectedLanguage;
      const levelMatch =
        this._selectedLevel === 'all' || course.level === this._selectedLevel;
      const categoryMatch =
        this._selectedCategory === 'all' ||
        course.category === this._selectedCategory;
      return languageMatch && levelMatch && categoryMatch;
    });
  }

  setLanguageFilter(language: Language) {
    this._selectedLanguage = language;
    this.notifyPropertyChange('filteredCourses', this.filteredCourses);
  }

  setLevelFilter(level: string) {
    this._selectedLevel = level;
    this.notifyPropertyChange('filteredCourses', this.filteredCourses);
  }

  setCategoryFilter(category: string) {
    this._selectedCategory = category;
    this.notifyPropertyChange('filteredCourses', this.filteredCourses);
  }

  private loadCourses() {
    // TODO: Replace with actual API call
    this._courses = [
      {
        id: '1',
        title: 'Introduction to Web Development',
        description: 'Learn the basics of web development',
        language: 'hindi',
        level: 'beginner',
        duration: 120,
        category: 'technology',
        thumbnailUrl: 'https://placeholder.com/course1.jpg',
        instructorName: 'Rahul Kumar',
        price: 999,
      },
      // Add more sample courses here
    ];
    this.notifyPropertyChange('courses', this._courses);
    this.notifyPropertyChange('filteredCourses', this.filteredCourses);
  }
}
