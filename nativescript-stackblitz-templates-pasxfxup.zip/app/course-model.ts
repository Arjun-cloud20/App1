export interface Course {
  id: string;
  title: string;
  description: string;
  language: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  duration: number; // in minutes
  category: string;
  thumbnailUrl: string;
  instructorName: string;
  price: number;
}

export type Language = 
  | 'hindi' 
  | 'bengali' 
  | 'telugu' 
  | 'marathi' 
  | 'tamil' 
  | 'urdu' 
  | 'gujarati' 
  | 'malayalam' 
  | 'kannada' 
  | 'punjabi' 
  | 'english';