import { EventData, Page } from '@nativescript/core';
import { CoursesViewModel } from './shared/view-models/courses-view-model';

let viewModel: CoursesViewModel;

export function navigatingTo(args: EventData) {
  const page = <Page>args.object;
  viewModel = new CoursesViewModel();
  page.bindingContext = viewModel;
}

export function onChangeLanguage(args: EventData) {
  // TODO: Implement language change dialog
  console.log('Change language tapped');
}
